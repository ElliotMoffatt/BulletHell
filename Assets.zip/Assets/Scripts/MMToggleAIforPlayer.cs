﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MMToggleAIforPlayer : GameController {

    private Toggle m_Toggle;

    // Use this for initialization
    void Start () {
        m_Toggle = GetComponent<Toggle>();
        m_Toggle.isOn = GameController.usePlayerAI;
        m_Toggle.onValueChanged.AddListener(delegate {
            GameController.usePlayerAI = m_Toggle.isOn;
        });
    }
	
	// Update is called once per frame
	void Update () {
        
	}
}
