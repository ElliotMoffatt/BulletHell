﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Tutorial : DifficultySettings {

    public GameObject player;
    public GameObject playerHealthBar;
    public GameObject nemesis;
    public GameObject nemesisHealthBar;
    public GameObject playerCannon;
    public GameObject nemesisCannon;
    new public GameObject score;

    int tutorialStep = 0;
    public static Text tutorialText;


    // Use this for initialization
    void Start () {
        tutorialText = GetComponent<Text>();
        player.SetActive(false);
        playerHealthBar.SetActive(false);
        nemesis.SetActive(false);
        nemesisHealthBar.SetActive(false);
        playerCannon.SetActive(false);
        nemesisCannon.SetActive(false);
        score.SetActive(false);
        tutorialText.text = "This is the tutorial.\nProgress by pressing space.";
    }
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown("space")) {
            TutorialInstructions();
        }
	}

    void TutorialInstructions()
    {
        switch (tutorialStep)
        {
            case 0:
                player.SetActive(true);
                playerCannon.SetActive(false);
                tutorialText.text = "You are green.\nMove with w a s d";
                tutorialStep += 1;
                break;
            case 1:
                playerHealthBar.SetActive(true);
                tutorialText.text = "You have a health bar.\nDon't let it reach 0";
                tutorialStep += 1;
                break;
            case 2:
                nemesis.SetActive(true);
                nemesisCannon.SetActive(false);
                nemesisHealthBar.SetActive(true);
                tutorialText.text = "Red is your nemesis.\nRed loses health over time";
                tutorialStep += 1;
                break;
            case 3:
                playerCannon.SetActive(true);
                tutorialText.text = "You also speed up Red's\ndemise by shooting it";
                tutorialStep += 1;
                break;
            case 4:
                nemesisCannon.SetActive(true);
                tutorialText.text = "Red can shoot back.\nDon't get hit too much";
                tutorialStep += 1;
                break;
            case 5:
                score.SetActive(true);
                tutorialText.text = "Increase your score by\nlanding shots on Red";
                tutorialStep += 1;
                break;
            case 6:
                tutorialText.text = "Press space to return to\nmain menu when ready";
                tutorialStep += 1;
                break;
            case 7:
                resetScore();
                LoadScene(0);
                break;
        }
    }
}
