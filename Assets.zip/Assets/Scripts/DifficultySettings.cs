﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DifficultySettings : GameController {

    //GameScore Variables
    protected static int[] baseScoreValue = {5,7,10,15,20,25,30,37,45,55,0,5};            //score value for hitting enemy once
    
    //Player Variables
    protected static int PlayerAttackDamage = 10;
    protected static float PassiveEnemyHealthLoss = 5;
    protected static int[] PlayerStartingHealth = { 100,50,60,50,25,100,100,100,100,40,0,10000 };
    protected static float PlayerBulletSpeed = 30;
    protected static float PlayerMoveSpeed = 8;
    protected static float PlayerFireRate = 0.2f;
    //Enemy Variables
    protected static int EnemyAttackDamage = 2;
    protected static int EnemyProjectileMass = 7;                               //between 1 and 10. a higher value makes the AI player better at dodging
    protected static float[] EnemyStartingHealth = { 500, 300, 500, 700, 600, 500, 500, 1000, 700, 600, 0, 50000 };
    protected static float[] EnemyBulletSpeed = { 5, 6, 5, 6, 4, 5, 5, 2, 5, 1, 0, 5 };
    protected static float[] EnemyMoveSpeed = {7,7,7,7,7,7,8,7,7,3,0,7};
    protected static float[] EnemyRotationSpeed = { -500, 500, -500, -500, 360, -500, -500, -500, -500, 600, 0, -500 };
    protected static float[] EnemyFireRate = { 0.03f, 0.02f, 0.015f, 0.010f, 0.02f, 0.015f, 0.015f, 0.015f, 0.02f, 0.02f, 0, 0.03f };

    // Use this for initialization
    void Start () {

    }
	
	// Update is called once per frame
	void Update () {
		
	}

}
