﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelsBeatManager : GameController {

    void Awake()
    {
        GameController.LevelsBeatText = GetComponent<Text>();
    }

    void Update()
    {
        GameController.LevelsBeatText.text = "Levels Completed: " + LevelsBeat;
    }
}
