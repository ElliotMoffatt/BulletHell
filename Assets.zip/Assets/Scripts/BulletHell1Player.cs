﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Boundary1
{
    public float xMin, xMax, zMin, zMax;
}


public class BulletHell1Player : DifficultySettings {

    private float PlayerSpeed = DifficultySettings.PlayerMoveSpeed;
    public Boundary1 boundary;

    public GameObject Shot;
    public Transform BulletSpawn;
    private float fireRate = DifficultySettings.PlayerFireRate;

    private float nextFire;

    //for AI
    GameObject Nemesis;

    void Update()
    {
       if( /*Input.GetButton("Jump") &&*/ Time.time > nextFire)
        {
            nextFire = Time.time + fireRate;
            Instantiate(Shot, BulletSpawn.position, BulletSpawn.rotation); 

        }
        if (GameController.usePlayerAI)
        {
            UpdatewithAI();
        }
        else
        {
            UpdateWithPlayerInput();
        }

    }

    void FixedUpdate()
    {

    }

    void UpdateWithPlayerInput()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        var movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
        if (movement.magnitude > 1f)
        {
            movement.Normalize();
        }
        var rigidbody = GetComponent<Rigidbody>();
        rigidbody.velocity = movement * PlayerSpeed;

        rigidbody.position = new Vector3
        (
            Mathf.Clamp(rigidbody.position.x, boundary.xMin, boundary.xMax),
            0.0f,
            Mathf.Clamp(rigidbody.position.z, boundary.zMin, boundary.zMax)
        );
    }

    void UpdatewithAI()
    {
        Vector3 CurrentPosition = GetComponent<Transform>().position;

        float moveHorizontal = 0;
        float moveVertical = 0;
        var movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
        if (GameController.numEnemies > 0)                                  //if there are enemies still alive
        {
            if (Nemesis == null || !Nemesis.activeSelf)
            {
                Nemesis = GameObject.FindWithTag("Enemy");
            }
            Vector3 NemesisPosition = Nemesis.transform.position;                      //position of enemy

            if (NemesisPosition.z < 2)                         //if nemesis moving down and close to bottom, move up
            {
                moveVertical = 50;
                if (NemesisPosition.x > 0)
                {
                    moveHorizontal = -10;
                    Debug.Log("Player AI Behaviour: Go top left");
                }
                else
                {
                    moveHorizontal = 10;
                    Debug.Log("Player AI Behaviour: Go top right");
                }

            }
            else if (NemesisPosition.z < 4)                         //if nemesis moving down, stop tracking, move away from it
            {
                if (NemesisPosition.x > 0)
                {
                    moveHorizontal = -20;
                    Debug.Log("Player AI Behaviour: Go left");
                }
                else
                {
                    moveHorizontal = 20;
                    Debug.Log("Player AI Behaviour: Go right");
                }

            }
            else if (NemesisPosition.z > 2 && CurrentPosition.z > 2)                         //if nemesis moving up and of right of screen
            {
                moveVertical = -50;
                if (NemesisPosition.x > 0)
                {
                    moveHorizontal = -10;
                    Debug.Log("Player AI Behaviour: Go bottom left");
                }
                else
                {
                    moveHorizontal = 10;
                    Debug.Log("Player AI Behaviour: Go bottom right");
                }

            }
            else
            { 
                if (CurrentPosition.z < -2f)
                {
                    moveVertical = 0.5f;
                }
                else if (CurrentPosition.z > 0.5f)
                {
                    moveVertical = -0.2f;
                }
                if (Mathf.Abs(CurrentPosition.x - NemesisPosition.x) > 0.2)            //follow horizontal movement of enemy to shoot it
                {
                    Debug.Log("Player AI Behaviour: Track nemesis");
                    if (CurrentPosition.x > NemesisPosition.x)
                    {
                        moveHorizontal = -1;
                    }
                    else
                    {
                        moveHorizontal = 1;
                    }
                }
            }
            movement = new Vector3(moveHorizontal, 0.0f, moveVertical);

            List<GameObject> nearbyProjectiles = getNearbyThreats(CurrentPosition);     //gets all nearby threats
            foreach (GameObject proj in nearbyProjectiles)
            {
                Vector3 force = getForce(CurrentPosition, proj.transform.position, DifficultySettings.EnemyProjectileMass);
                movement += force;
            }
            GameObject[] EnemyObjects = GameObject.FindGameObjectsWithTag("Enemy");
            for(int i=0; i < EnemyObjects.Length; i++)
            {
                Vector3 force = getForce(CurrentPosition, EnemyObjects[i].transform.position, 30);
                movement += force;
            }

            if (CurrentPosition.z > boundary.zMax-1)        //if near top of screen, not allowed to go up
            {
                movement.z = -1;
            }


            if (movement.magnitude > 1f)
            {
                movement.Normalize();
            }
        }
        else                    //if no nemeses, reset position to centre
        {
            movement = new Vector3(-gameObject.transform.position.x, 0.0f, -gameObject.transform.position.z);
            if (movement.magnitude > 1f)
            {
                movement.Normalize();
            }
        }

      



        //movement.Normalize();
        var rigidbody = GetComponent<Rigidbody>();
        rigidbody.velocity = movement * PlayerSpeed;

        rigidbody.position = new Vector3
        (
            Mathf.Clamp(rigidbody.position.x, boundary.xMin, boundary.xMax),
            0.0f,
            Mathf.Clamp(rigidbody.position.z, boundary.zMin, boundary.zMax)
        );
    }


    List<GameObject> getNearbyThreats(Vector3 CurrentPosition)
    {
        Collider[] hitColliders = Physics.OverlapSphere(CurrentPosition, 0.9f);      //list of all colliders within x units of centre of player
        List<GameObject> nearbyProjectiles = new List<GameObject>();
        for (int i = 0; i < hitColliders.Length; i++)                                 //add all nearby projectiles to list
        {
            if (hitColliders[i].gameObject.tag == "EnemyProjectile")
            {
                nearbyProjectiles.Add(hitColliders[i].gameObject);
            }
        }
        return nearbyProjectiles;
    }

    Vector3 getForce(Vector3 playerPos, Vector3 enemyPos, float mass)
    {
        Vector3 forceVector = new Vector3(playerPos.x - enemyPos.x, 0.0f, playerPos.z - enemyPos.z);
        float magnitude = mass / forceVector.sqrMagnitude;
        forceVector.Normalize();

        return forceVector * magnitude;
    }
}
