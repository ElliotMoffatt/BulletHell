﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerHealth : DifficultySettings {

    protected int startingHealth;
    [SerializeField]
    private int currentHealth;
    public Slider healthSlider;

    void Awake()
    {
        startingHealth = DifficultySettings.PlayerStartingHealth[GameController.CurrentScene - 1];
        currentHealth = startingHealth;
        healthSlider.maxValue = startingHealth;
        healthSlider.value = currentHealth;
    }

    public void TakeDamage(int amount)
    {
        currentHealth -= amount;
        healthSlider.value = currentHealth;
        if (currentHealth <= 0)
        {
            Destroy(gameObject);
            LoadScene(GameController.GameOverSceneNum);
        }
    }

}
