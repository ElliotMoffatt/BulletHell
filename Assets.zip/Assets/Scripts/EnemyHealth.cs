﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class EnemyHealth : DifficultySettings
{

    private float startingHealth;
    public float currentHealth;
    public Slider healthSlider;
    public float passiveDamage;

    void Awake()
    {
        startingHealth = DifficultySettings.EnemyStartingHealth[GameController.CurrentScene - 1];
        currentHealth = startingHealth;
        healthSlider.maxValue = startingHealth;
        healthSlider.value = currentHealth;
        passiveDamage = DifficultySettings.PassiveEnemyHealthLoss;
    }

    void Update()
    {
        TakeDamage(0);
    }

    public void TakeDamage(float amount)
    {
        currentHealth -= passiveDamage * Time.deltaTime;
        currentHealth -= amount;
        healthSlider.value = currentHealth;
        if (currentHealth <= 0)
        {
            gameObject.SetActive(false);
            GameController.numEnemies -= 1;
            if (GameController.numEnemies <= 0)
            {
                GameController.CurrentLvLBeat = true;
                ScoreManager.score += Mathf.RoundToInt(DifficultySettings.baseScoreValue[CurrentScene - 1] * DifficultySettings.EnemyStartingHealth[CurrentScene - 1]);
                GameController.LevelBeatTime = Time.time;
            }
        }
    }


}
