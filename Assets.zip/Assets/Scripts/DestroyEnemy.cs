﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyEnemy : DifficultySettings {

    private int scoreValue;
    private int attackDamage = DifficultySettings.PlayerAttackDamage;
    GameObject[] EnemyObjects;


    void Awake()
    {
        scoreValue = DifficultySettings.baseScoreValue[GameController.CurrentScene -1];
        EnemyObjects = GameController.CurrentLevelEnemies;
    }

    void OnTriggerEnter(Collider other)
    {
        foreach (GameObject Enemy in EnemyObjects)
        {
            if (Enemy.Equals(other.gameObject))
            {
                EnemyHealth Ehealth = Enemy.GetComponent<EnemyHealth>();
                Ehealth.TakeDamage(attackDamage);
                ScoreManager.score += scoreValue;
                Destroy(gameObject);
            }
        }
    }
}
