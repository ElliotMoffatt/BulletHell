﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class DestroyUs : DifficultySettings {

    private int attackDamage;
    GameObject PlayerObject;
    PlayerHealth health;

    void Start()
    {

        attackDamage = DifficultySettings.EnemyAttackDamage;  


        PlayerObject = GameObject.FindGameObjectWithTag("Player");
        if (PlayerObject != null)
        {
            health = PlayerObject.GetComponent<PlayerHealth>();
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.gameObject == PlayerObject)
        {
            if(!GameController.CurrentLvLBeat)
            {
                health.TakeDamage(attackDamage);
            }
            Destroy(gameObject);
        }
    }

}
