﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {

    //Scene Management
    protected static int CurrentScene;
    protected static bool CurrentLvLBeat;
    protected static float LevelBeatTime;
    public static GameObject LoadingScreen;
    protected static int GameOverSceneNum = 11;

    //PlayerAI variables
    public static bool usePlayerAI = false;

    //GameScore Variables
    protected static int score = 0;
    protected static Text scoreText;
    protected static int LevelsBeat = 0;
    protected static Text LevelsBeatText;

    //EnemyNumber Variables
    protected static int numEnemies;
    protected static GameObject[] CurrentLevelEnemies;

    // Use this for initialization
    void Start()
    {
        CurrentScene = SceneManager.GetActiveScene().buildIndex;
        CurrentLvLBeat = false;
        CurrentLevelEnemies = GameObject.FindGameObjectsWithTag("Enemy");
        numEnemies = CurrentLevelEnemies.Length;
        //  LoadingScreen = GameObject.Instantiate(UnityEditor.AssetDatabase.LoadAssetAtPath("Assets/Prefabs/LoadingScreen.prefab", typeof(GameObject))) as GameObject;
    }

    void Update()
    {
        if(Input.GetKeyDown("escape"))
        {
            resetScore();
            LoadScene(0);
        }
        if (CurrentLvLBeat)
        {
            EndOfLevel(LevelBeatTime);
        }
    }

    public void LoadScene(int scene)    //loads new scene and prepares variables for current scene
    {
      //  LoadingScreen.SetActive(true);
        CurrentScene = scene;
        Debug.Log("Next scene = " + CurrentScene);
        SceneManager.LoadScene(scene);
    //    LoadingScreen.SetActive(false);
    }

    public void EndOfLevel(float beatTime)
    {
        if (Time.time > beatTime + 3)
        {
            LevelsBeat += 1;
            LoadScene(CurrentScene + 1);
        }
    }

    public void resetScore()
    {
        score = 0;
        LevelsBeat = 0;
    }

}
