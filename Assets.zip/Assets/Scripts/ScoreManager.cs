﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : GameController {

    void Awake()
    {
        GameController.scoreText = GetComponent<Text>();
    }

    void Update()
    {
        GameController.scoreText.text = "Score: " + score;
    }
}
