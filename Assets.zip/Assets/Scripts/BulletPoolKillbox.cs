﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletPoolKillbox : MonoBehaviour {

    // These 3 functions set a bullet as inactive after 2 seconds
    void OnEnable()
    {
        Invoke("Destroy", 1.5f);
    }

    void Destroy()
    {
        gameObject.SetActive(false);
    }

    void OnDisable()
    {
        CancelInvoke();
    }
}
