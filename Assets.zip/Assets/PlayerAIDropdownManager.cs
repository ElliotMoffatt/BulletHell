﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerAIDropdownManager : DifficultySettings {

    Dropdown m_Dropdown;

	// Use this for initialization
	void Start () {
        m_Dropdown = GetComponent<Dropdown>();
        m_Dropdown.value = DifficultySettings.EnemyProjectileMass/2;

    }
	
	// Update is called once per frame
	void Update () {
        DifficultySettings.EnemyProjectileMass = m_Dropdown.value*2;
	}
}
